# __init__.py

# Version of the frankAllSkyCam
__version__ = "10.3"
